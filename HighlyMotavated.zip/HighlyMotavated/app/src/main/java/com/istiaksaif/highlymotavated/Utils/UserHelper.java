//package com.istiaksaif.highlymotavated.Utils;
//
//import android.app.Activity;
//import android.content.Context;
//import android.view.Display;
//import android.view.WindowManager;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.Query;
//import com.google.firebase.database.ValueEventListener;
//import com.istiaksaif.highlymotavated.Activity.ProfileActivity;
//import com.istiaksaif.highlymotavated.Model.User;
//import com.istiaksaif.highlymotavated.R;
//import com.squareup.picasso.Picasso;
//
//public class UserHelper {
//    private static Fragment fragment;
//    private static Activity activity;
//    private static Context context;
//    private DatabaseReference databaseReference,dataRef;
//    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//    private String uid = user.getUid();
//
//    public UserHelper(Fragment fragment, Activity activity,Context context) {
//        this.fragment = fragment;
//        this.activity = activity;
//        this.context = context;
//        databaseReference = FirebaseDatabase.getInstance().getReference();
//        dataRef = FirebaseDatabase.getInstance().getReference();
//    }
//
//    public String UserKeyImg() {
//        if (activity!=null) {
//            Query query = databaseReference.child("users").orderByChild("userId").equalTo(uid);
//            query.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    for(DataSnapshot dataSnapshot:snapshot.getChildren()) {
//                        String key = dataSnapshot.child("key").getValue().toString();
//                        return key;
////                        dataRef.child("usersData").child(key)
////                                .addValueEventListener(new ValueEventListener() {
////                                    @Override
////                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot2) {
////                                        String retrivename = ""+dataSnapshot2.child("name").getValue();
////                                        String blood = dataSnapshot2.child("bloodgroup").getValue().toString();
////                                        String retriveEmail = ""+dataSnapshot2.child("email").getValue();
////                                        String img = dataSnapshot2.child("imageUrl").getValue().toString();
////                                        String receivephone = ""+dataSnapshot2.child("phone").getValue();
////                                        String retriveaddress = ""+dataSnapshot2.child("address").getValue();
////                                        String retrivetitle = ""+dataSnapshot2.child("title").getValue();
//////                                    String balancetk = " "+dataSnapshot2.child("balanceTk").getValue()+" ";
////                                        User userd= new User();
////                                        userd.setImageUrl(img);
////                                        userd.setKey(key);
////                                    }
////
////                                    @Override
////                                    public void onCancelled(@NonNull DatabaseError error) {
////
////                                    }
////                                });
//                    }
//                }
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//
//                }
//            });
//        }else if(fragment!=null){
//
//        }else {
//
//        }
//    }
//}
