package com.istiaksaif.highlymotavated.Utils;

import android.app.Activity;
import android.content.Context;
import android.os.CountDownTimer;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class test {
//    Context context;
    static String url = "https://www.timeapi.io/api/Time/current/zone?timeZone=America/New_York";
    static RequestQueue requestQueue;

    public test() {
    }
    private static Fragment fragment;
    private static Activity activity;
    private static Context context;

    public test(Fragment fragment, Activity activity,Context context) {
        this.fragment = fragment;
        this.activity = activity;
        this.context = context;
    }
    public test(Context context) {
        this.context = context;
        requestQueue = Volley.newRequestQueue(context);
    }

    public static void getDateTim(VolleyCallBack volleyCallBack){
        JSONObject jsonObject = new JSONObject();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            volleyCallBack.onGetDateTime(response.getString("dateTime"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(jsonObjectRequest);
    }
    public interface VolleyCallBack{
        void onGetDateTime(String dateTime);
    }
    public void gettime(String timer){
        getDateTim(new VolleyCallBack(){
            @Override
            public void onGetDateTime(String dateTime) {
                String splitTime[] = dateTime.split("T");
                String time = splitTime[0]+" "+splitTime[1];
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = null;
                try {
                    date = sdf.parse(time);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                long timestamp = date.getTime();
                long endTimestamp = (Long.parseLong(timer))-timestamp;
                new CountDownTimer(endTimestamp, 1000) {
                    @Override
                    public void onTick(long l) {
                        String sduration = String.format(Locale.ENGLISH,"%02d : %02d : %02d",
                                TimeUnit.MILLISECONDS.toHours(l),
                                TimeUnit.MILLISECONDS.toMinutes(l) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(l)),
                                TimeUnit.MILLISECONDS.toSeconds(l) -
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(l)));
//                        holder.counttimertext.setText(sduration);
//                        return sduration;
                        sendoutput(sduration);
                    }

                    @Override
                    public void onFinish() {
                        String s = "00 : 00 : 00";
                        sendoutput(s);
                    }
                }.start();
            }
        });
    }

    public static String sendoutput(String sduration) {
        if (activity!=null) {
            return sduration;
        }else if(fragment!=null){
            return sduration;
        }else {
            return sduration;
        }
    }

}

