package com.istiaksaif.highlymotavated.Fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.istiaksaif.highlymotavated.Adapter.ProductListAdapter;
import com.istiaksaif.highlymotavated.Model.ProductItem;
import com.istiaksaif.highlymotavated.R;
import com.istiaksaif.highlymotavated.Receiver.Dao;
import com.istiaksaif.highlymotavated.Utils.CheckInternet;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private RecyclerView productrecycler;
    private ProductListAdapter postProductListAdapter;
    private ArrayList<ProductItem> productItemArrayList;
    private DatabaseReference databaseReference;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String uid = user.getUid();
    private TextView checkInternet;
    boolean isLoading = false;
    private Dao dao;
    private String key=null;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        databaseReference = FirebaseDatabase.getInstance().getReference();
        productItemArrayList = new ArrayList<>();
        checkInternet = view.findViewById(R.id.networkcheck);
        swipeRefreshLayout = view.findViewById(R.id.swip);

        productrecycler = view.findViewById(R.id.myPostRecycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        productrecycler.setLayoutManager(layoutManager);
        productrecycler.setHasFixedSize(true);
        dao = new Dao();
        GetDataFromFirebase();
        productrecycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
//                LinearLayoutManager layoutManager1 = (LinearLayoutManager) productrecycler.getLayoutManager();
                int totalitem = layoutManager.getItemCount();
                int lastVisible = layoutManager.findLastCompletelyVisibleItemPosition();
                if(totalitem<lastVisible+3){
                    if(!isLoading){
                        isLoading = true;
                        GetDataFromFirebase();
                    }
                }
            }
        });
    }
//    private void GetDataFromFirebase() {
//        Query query = databaseReference.child("Products");
//        query.orderByKey()
//                .limitToLast(5).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                ClearAll();
//                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                    try {
//                        ProductItem item = new ProductItem();
//                        item.setProductname(snapshot.child("productName").getValue().toString());
//                        item.setProductprice(snapshot.child("productPrice").getValue().toString());
//                        item.setProductId(snapshot.child("productId").getValue().toString());
//                        item.setDatetime(snapshot.child("timestamp").getValue().toString());
//                        item.setEnddate(snapshot.child("endTimestamp").getValue().toString());
//                        item.setBiders(Long.toString(snapshot.child("Bidders").getChildrenCount()));
//                        String userid = snapshot.child("userId").getValue().toString();
//                        for (DataSnapshot snapshot1: snapshot.child("Images").getChildren()){
//                            item.setProductimage(snapshot1.child("productImage").getValue().toString());
//                        }
//                        item.setUserimage(userid);
//                        productItemArrayList.add(item);
//
//                    } catch (Exception e) {
//
//                    }
//                    postProductListAdapter = new ProductListAdapter(getContext(), productItemArrayList);
//                    productrecycler.setAdapter(postProductListAdapter);
//                    postProductListAdapter.notifyDataSetChanged();
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }

    private void GetDataFromFirebase() {
        swipeRefreshLayout.setRefreshing(true);
        dao.get(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    try {
                        ProductItem item = new ProductItem();
                        item.setProductname(snapshot.child("productName").getValue().toString());
                        item.setProductprice(snapshot.child("productPrice").getValue().toString());
                        item.setProductdes(snapshot.child("productDescription").getValue().toString());
                        item.setProductId(snapshot.child("productId").getValue().toString());
                        item.setDatetime(snapshot.child("timestamp").getValue().toString());
                        item.setEnddate(snapshot.child("endTimestamp").getValue().toString());
                        item.setBiders(Long.toString(snapshot.child("Bidders").getChildrenCount()));
                        String userid = snapshot.child("userId").getValue().toString();
                        for (DataSnapshot snapshot1: snapshot.child("Images").getChildren()){
                            item.setProductimage(snapshot1.child("productImage").getValue().toString());
                        }
                        item.setUserId(userid);
                        productItemArrayList.add(item);
                        key = snapshot.getKey();

                    } catch (Exception e) {

                    }
                }
                postProductListAdapter = new ProductListAdapter(getContext(), productItemArrayList);
                productrecycler.setAdapter(postProductListAdapter);
                postProductListAdapter.notifyDataSetChanged();
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void ClearAll(){
        if (productItemArrayList !=null){
            productItemArrayList.clear();
            if (postProductListAdapter !=null){
                postProductListAdapter.notifyDataSetChanged();
            }
        }
        productItemArrayList = new ArrayList<>();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if(!CheckInternet.isConnectedToInternet(getActivity())){
            checkInternet.setVisibility(View.VISIBLE);
        }else {
            checkInternet.setVisibility(View.GONE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if(!CheckInternet.isConnectedToInternet(getActivity())){
            checkInternet.setVisibility(View.VISIBLE);
        }else {
            checkInternet.setVisibility(View.GONE);
        }
    }
}