package com.istiaksaif.highlymotavated.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.istiaksaif.highlymotavated.Adapter.ProductListAdapter;
import com.istiaksaif.highlymotavated.Fragment.HomeFragment;
import com.istiaksaif.highlymotavated.Model.ProductItem;
import com.istiaksaif.highlymotavated.Model.User;
import com.istiaksaif.highlymotavated.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class UserHomeActivity extends AppCompatActivity {

    private Toolbar toolbar;

    private long backPressedTime;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private RelativeLayout cross;
    private CardView cardView;
    private LinearLayout logoutButton;

    private TextView appVersion,storekey,storeimg,n,t;
    private ImageView profileimage,i;

    private GoogleSignInClient googleSignInClient;
    private RecyclerView productrecycler;
    private ProductListAdapter postProductListAdapter;
    private ArrayList<ProductItem> productItemArrayList;
    private DatabaseReference databaseReference;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String uid = user.getUid();
    private View hView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportFragmentManager().beginTransaction().add(R.id.container,new HomeFragment()).commit();

        databaseReference = FirebaseDatabase.getInstance().getReference();

        storekey = findViewById(R.id.keystore);
        storeimg = findViewById(R.id.imgstore);
        profileimage = findViewById(R.id.profileimage);
        //appDrawer

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.drawer_menu);
        hView = navigationView.getHeaderView(0);


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
        actionBarDrawerToggle.setHomeAsUpIndicator(R.drawable.ic_menu);

        actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        i = hView.findViewById(R.id.profileimage);
        n = hView.findViewById(R.id.name);
        t = hView.findViewById(R.id.title);

        hView.findViewById(R.id.cross).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawer(GravityCompat.START);
            }
        });
        GetDataFromFirebase();
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.profile) {
                    Intent i = new Intent(UserHomeActivity.this, ProfileActivity.class);
                    i.putExtra("key",storekey.getText().toString());
                    i.putExtra("imageUrl",storeimg.getText().toString());
                    startActivity(i);
                }
                if (id == R.id.post){
                    Intent i = new Intent(UserHomeActivity.this, MyPostActivity.class);
                    startActivity(i);
                }
                if (id == R.id.addproduct) {
                    Intent a = new Intent(UserHomeActivity.this, AddProductActivity.class);
                    startActivity(a);
                }
                if (id == R.id.bid) {
                    Intent a = new Intent(UserHomeActivity.this, BidHistoryActivity.class);
                    startActivity(a);
                }
                if (id == R.id.notification) {
                    Intent as = new Intent(UserHomeActivity.this, NotificationActivity.class);
                    startActivity(as);
                }
                if (id == R.id.faq) {

                }
                if (id == R.id.logout) {
                    signOut();
                }

                return false;
            }
        });

        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail().build();
        googleSignInClient = GoogleSignIn.getClient(this,googleSignInOptions);

        //version on menu
        appVersion = findViewById(R.id.app_version);
        PackageManager manager = getApplication().getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(
                    getApplication().getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = info.versionName;
        appVersion.setText("Version "+version);
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkStatus("online");
    }
    @Override
    protected void onPause() {
        super.onPause();
        checkStatus("offline");
    }

    private void checkStatus(String status){
        HashMap<String, Object> result = new HashMap<>();
        result.put("status",status);

        databaseReference.child("users").child(uid).updateChildren(result);
    }

    private void GetDataFromFirebase() {
        Query query = databaseReference.child("users").orderByChild("userId").equalTo(uid);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot:snapshot.getChildren()) {
                    String key = dataSnapshot.child("key").getValue().toString();
                    storekey.setText(key);
                    databaseReference.child("usersData").child(key)
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot2) {
                                    String retrivename = ""+dataSnapshot2.child("name").getValue();
                                    String retrivetitle = ""+dataSnapshot2.child("title").getValue();
                                    String img = dataSnapshot2.child("imageUrl").getValue().toString();
                                    storeimg.setText(img);
                                    n.setText(retrivename);
                                    t.setText(retrivetitle);
                                    try {
                                        Picasso.get().load(img).resize(320,320).into(profileimage);
                                    }catch (Exception e){
                                        Picasso.get().load(R.drawable.dropdown).into(profileimage);
                                    }
                                    try {
                                        Picasso.get().load(img).resize(480,480).into(i);
                                    }catch (Exception e){
                                        Picasso.get().load(R.drawable.dropdown).into(i);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case android.R.id.home:
                finish();
        }return true;
    }

    private void signOut(){
        FirebaseAuth.getInstance().signOut();
        googleSignInClient.signOut();
        Intent intent1 = new Intent(this, LogInActivity.class);
        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent1);
    }

    public void onBackPressed(){
        if(backPressedTime + 2000>System.currentTimeMillis()){
            super.onBackPressed();
            return;
        }else{
            Toast.makeText(getBaseContext(),"Press Back Again to Exit",Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }
}