package com.istiaksaif.highlymotavated.Model;

import java.io.Serializable;

public class ProductItem implements Serializable {
    private String productimage,userimage,userName,productname,productdes,reply,productId,
            category,datetime,productdays,productprice,biders,enddate,userId;

    public ProductItem() {
    }

    public ProductItem(String productimage, String userimage, String userName, String productname, String productdes, String reply, String productId, String category, String datetime, String productdays, String productprice, String biders) {
        this.productimage = productimage;
        this.userimage = userimage;
        this.userName = userName;
        this.productname = productname;
        this.productdes = productdes;
        this.reply = reply;
        this.productId = productId;
        this.category = category;
        this.datetime = datetime;
        this.productdays = productdays;
        this.productprice = productprice;
        this.biders = biders;
    }

    public String getProductimage() {
        return productimage;
    }

    public void setProductimage(String productimage) {
        this.productimage = productimage;
    }

    public String getUserimage() {
        return userimage;
    }

    public void setUserimage(String userimage) {
        this.userimage = userimage;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getProductdes() {
        return productdes;
    }

    public void setProductdes(String productdes) {
        this.productdes = productdes;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getProductdays() {
        return productdays;
    }

    public void setProductdays(String productdays) {
        this.productdays = productdays;
    }

    public String getProductprice() {
        return productprice;
    }

    public void setProductprice(String productprice) {
        this.productprice = productprice;
    }

    public String getBiders() {
        return biders;
    }

    public void setBiders(String biders) {
        this.biders = biders;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
