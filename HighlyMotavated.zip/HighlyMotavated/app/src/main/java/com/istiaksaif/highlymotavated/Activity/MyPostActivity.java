package com.istiaksaif.highlymotavated.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.istiaksaif.highlymotavated.Adapter.PostProductListAdapter;
import com.istiaksaif.highlymotavated.Model.ProductItem;
import com.istiaksaif.highlymotavated.R;
import com.istiaksaif.highlymotavated.Receiver.Dao;

import java.util.ArrayList;

public class MyPostActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private ImageView addProduct;
    private RecyclerView productrecycler;
    private PostProductListAdapter postProductListAdapter;
    private ArrayList<ProductItem> productItemArrayList;
    private DatabaseReference databaseReference;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String uid = user.getUid();
    private TextView checkInternet;
    boolean isLoading = false;
    private Dao dao;
    private String key=null;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_post);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.leftarrow);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        addProduct = findViewById(R.id.addproduct);
        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyPostActivity.this, AddProductActivity.class);
                startActivity(intent);
            }
        });
        databaseReference = FirebaseDatabase.getInstance().getReference();
        productItemArrayList = new ArrayList<>();
        swipeRefreshLayout = findViewById(R.id.swip);
        productrecycler = findViewById(R.id.myPostRecycler);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        productrecycler.setLayoutManager(layoutManager);
        productrecycler.setHasFixedSize(true);
        dao = new Dao();
        GetDataFromFirebase();
        recfun(layoutManager);
//        productrecycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
//            @Override
//            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
////                super.onScrolled(recyclerView, dx, dy);
//                LinearLayoutManager layoutManager1 = (LinearLayoutManager) productrecycler.getLayoutManager();
//                int totalitem = layoutManager1.getItemCount();
//                int lastVisible = layoutManager1.findLastCompletelyVisibleItemPosition();
//                if(totalitem<lastVisible+3){
//                    if(!isLoading){
//                        isLoading = true;
//                        GetDataFromFirebase();
//                    }
//                }
//            }
//        });
    }

    private void recfun(LinearLayoutManager manager) {
        productrecycler.addOnScrollListener(new RecyclerView.OnScrollListener()
        {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState)
            {
                super.onScrollStateChanged(recyclerView, newState);
                if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL)
                {
                    isLoading=true;
                }

            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy)
            {
//                super.onScrolled(recyclerView, dx, dy);

                int currentitems=manager.getChildCount();
                int tottalitems=manager.getItemCount();
                int scrolledoutitems=manager.findFirstVisibleItemPosition();

                if( isLoading && currentitems + scrolledoutitems == tottalitems)
                {
                    isLoading=false;
                    GetDataFromFirebase();

                }

            }
        });
    }

    private void GetDataFromFirebase() {
        swipeRefreshLayout.setRefreshing(true);
        dao.get(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    try {
                        ProductItem item = new ProductItem();
                        item.setProductname(snapshot.child("productName").getValue().toString());
                        item.setProductprice(snapshot.child("productPrice").getValue().toString());
                        item.setProductId(snapshot.child("productId").getValue().toString());
                        item.setEnddate(snapshot.child("endTimestamp").getValue().toString());
                        item.setBiders(Long.toString(snapshot.child("Bidders").getChildrenCount()));
                        String userid = snapshot.child("userId").getValue().toString();
                        for (DataSnapshot snapshot2: snapshot.child("Images").getChildren()){
                            item.setProductimage(snapshot2.child("productImage").getValue().toString());
                        }
                        item.setUserId(userid);
                        productItemArrayList.add(item);
                        key = snapshot.getKey();

                    } catch (Exception e) {

                    }
                }
                postProductListAdapter = new PostProductListAdapter(MyPostActivity.this, productItemArrayList);
                productrecycler.setAdapter(postProductListAdapter);
                postProductListAdapter.notifyDataSetChanged();
                isLoading = false;
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void ClearAll(){
        if (productItemArrayList !=null){
            productItemArrayList.clear();
            if (postProductListAdapter !=null){
                postProductListAdapter.notifyDataSetChanged();
            }
        }
        productItemArrayList = new ArrayList<>();
    }
}