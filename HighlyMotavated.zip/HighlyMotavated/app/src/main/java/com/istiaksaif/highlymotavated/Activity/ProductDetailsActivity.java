package com.istiaksaif.highlymotavated.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.istiaksaif.highlymotavated.Model.ProductItem;
import com.istiaksaif.highlymotavated.R;
import com.istiaksaif.highlymotavated.Utils.GetServerTimeContext;
import com.istiaksaif.highlymotavated.Utils.ScreenSizeGetHelper;
import com.istiaksaif.highlymotavated.Utils.test;

public class ProductDetailsActivity extends AppCompatActivity {
    private ImageView productImage,userImg;
    private TextView productName,userName,productPrice,counttimertext,biders,productDes;
    private CardView button;

    private ProductItem productItem;
    private Toolbar toolbar;
    private GetServerTimeContext getServerTime;
    private ScreenSizeGetHelper screenSizeGetHelper;
    private DatabaseReference databaseReference,dataRef;
    private FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    private String uid = user.getUid();
    private test testf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        if (getIntent().getExtras() != null) {
            productItem = (ProductItem) getIntent().getSerializableExtra("productObjects");
        }

        getServerTime = new GetServerTimeContext(this);
        screenSizeGetHelper = new ScreenSizeGetHelper(null,this,null);
        testf = new test(null,this,null);

        databaseReference = FirebaseDatabase.getInstance().getReference();
        dataRef = FirebaseDatabase.getInstance().getReference();

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.leftarrow);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        productImage = findViewById(R.id.productimage);
        userImg = findViewById(R.id.sellerimage);
        productName = findViewById(R.id.productname);
        productPrice = findViewById(R.id.bidprice);
        biders = findViewById(R.id.biders);
        button = findViewById(R.id.bidbutton);
        counttimertext = findViewById(R.id.counttimertext);
        userName = findViewById(R.id.sellername);
        productDes = findViewById(R.id.productdescription);

        productImage.getLayoutParams().height = (screenSizeGetHelper.ScreenHeightSize() /11)*5;
        productName.setText(productItem.getProductname());
        productDes.setText(productItem.getProductdes());
        productPrice.setText("ETH "+productItem.getProductprice());
        biders.setText(productItem.getBiders()+" bids");
        userName.setText(productItem.getUserName());
        Glide.with(this).load(productItem.getProductimage()).placeholder(R.drawable.dropdown).into(productImage);
        Glide.with(this).load(productItem.getUserimage()).placeholder(R.drawable.dropdown).into(userImg);

        testf.gettime(productItem.getEnddate());
//        counttimertext.setText(testf.sendoutput());
    }
}