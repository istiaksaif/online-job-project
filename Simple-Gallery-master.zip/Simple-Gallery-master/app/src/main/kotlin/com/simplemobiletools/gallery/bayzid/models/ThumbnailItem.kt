package com.simplemobiletools.gallery.bayzid.models

open class ThumbnailItem
