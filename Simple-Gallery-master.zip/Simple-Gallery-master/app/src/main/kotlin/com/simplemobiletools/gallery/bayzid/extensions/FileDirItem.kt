package com.simplemobiletools.gallery.bayzid.extensions

import com.simplemobiletools.commons.models.FileDirItem

fun FileDirItem.isDownloadsFolder() = path.isDownloadsFolder()
