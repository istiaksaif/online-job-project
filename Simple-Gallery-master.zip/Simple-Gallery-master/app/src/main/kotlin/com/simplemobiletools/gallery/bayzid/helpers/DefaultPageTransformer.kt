package com.simplemobiletools.gallery.bayzid.helpers

import android.view.View
import androidx.viewpager.widget.ViewPager

class DefaultPageTransformer : ViewPager.PageTransformer {
    override fun transformPage(view: View, position: Float) {}
}
