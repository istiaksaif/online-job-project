package com.simplemobiletools.gallery.bayzid.models

data class ThumbnailSection(val title: String) : ThumbnailItem()
