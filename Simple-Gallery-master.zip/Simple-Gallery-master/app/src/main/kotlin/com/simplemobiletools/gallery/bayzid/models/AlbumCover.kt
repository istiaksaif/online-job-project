package com.simplemobiletools.gallery.bayzid.models

data class AlbumCover(val path: String, val tmb: String)
